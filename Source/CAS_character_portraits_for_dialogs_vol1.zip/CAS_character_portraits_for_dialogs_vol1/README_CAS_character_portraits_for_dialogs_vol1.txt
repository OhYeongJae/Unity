﻿README_Unity-Chan_Cogen-City_All_Stars_character_portraits_for_dialogs_Vol.1.TXT

『Unity-Chan! コーゲンシティ・オールスターズ キャラクター立ち絵パック Vol.1』

2016/03/31 Unity Technologies Japan


【配布ライセンス】
本デジタルアセットデータは「ユニティちゃんライセンス条項（UCL）」（配布時点での最新版は、UCL 2.00）に基づき公開されるデジタルアセットデータです。
最新版の「ユニティちゃんライセンス条項」は以下をご確認ください。

ユニティちゃんライセンス条項・要約
http://unity-chan.com/contents/guideline/

ユニティちゃんライセンス条項・正文
http://unity-chan.com/contents/license_jp/

キャラクター利用のガイドライン（FAQ）
http://unity-chan.com/contents/faq/

特にFAQでは、本ライセンスの元で、クリエイターの皆さんが「できること」「できないこと」を詳しく具体例をあげて説明しています。
使用前に必ずご一読していただけますよう、よろしくお願いします。


【お問い合わせ先】

ユニティ・テクノロジーズ・ジャパン合同会社
unity-chan@unity3d.co.jp

